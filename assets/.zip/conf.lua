function love.conf(t)
    t.window.title = "Quick, sort!"
    t.window.width = 640
    t.window.height = 960
    t.window.highdpi = true
end
